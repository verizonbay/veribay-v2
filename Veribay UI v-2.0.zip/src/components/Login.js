import React from 'react'

import Joi from 'joi-browser'
import axios from 'axios'

import Form from '../common/Form';

export default class Login extends Form {

    componentDidMount() {
        axios.get("http://192.168.20.121:8098/getUsers")
            .then(response =>
                 {
                     console.log(response.data)
                     //localStorage.setItem("photo",res)
                    this.setState({
                        users: response.data
                    })
                 }
            )
            .catch(error => console.log(error))
    }

    state = {
        data: { email: "", password: "" },
        errors: {},
        users: []
    }

    schema = {
        email: Joi.string().required().label("Email Id"),
        password: Joi.string().required().label("Password")
    }
    validate = () => {

        const options = { abortEarly: false }
        const { error } = Joi.validate(
            {
                email: this.state.email,
                password: this.state.password
            }, this.schema, options
        )

        if (!error) return null;

        const errors = {}
        for (let item of error.details)
            errors[item.path[0]] = item.message

        console.log(errors)
        return errors

    }

    doSubmit = () => {
        console.log(this.state.email, this.state.password)
        console.log(this.state.users)
        this.state.users.map(
            data => {
                if (this.state.email === data.email && this.state.password === data.password) {
                    console.log(data.profilephoto)
                    localStorage.setItem("photo", data.profilephoto)
                    localStorage.setItem("userData", this.state.email + "-" + this.state.password)
                    console.log("Logged in with " + this.state.email + " " + this.state.password)
                   window.location = "/"
                }
                return ""
            }
        )


    }

    render() {
        return (
            <div>
                <h1>Login</h1>
                <form onSubmit={this.submitLoginForm}>
                    {this.renderInput({ name: "email", label: "Email ID", labelName: "Email-ID", type: "email", placeholder: "Enter Email ID" })}
                    {this.renderInput({ name: "password", label: "Password", labelName: "Password", type: "password", placeholder: "Password" })}
                    {this.renderButton("Login")}
                </form>
            </div>


        )
    }
}