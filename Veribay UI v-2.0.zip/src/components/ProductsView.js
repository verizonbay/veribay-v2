import React from 'react'
import axios from 'axios'
import Product from './Product';

export default class ProductsView extends React.Component {

    constructor() {
        super()
        this.state = {
            productsList: []
        }
    }

    componentDidMount() {
        axios.get("http://192.168.20.121:9098/getProducts")
            .then(response => {
                this.setState({
                    productsList: response.data
                })
            }
            )
            .catch(error => console.log(error))
    }

    goBack = () => {
        this.setState({
            showProduct: false
        })
    }

    displayProduct = (event) => {

        if(localStorage.getItem("userData")==null){
            alert("Please Login First")
            return
        }
        this.setState({
            showProduct: true,
            productId: event.target.name
        })
    }

    render() {

        let products = (this.state.productsList.length > 0) ? this.state.productsList.map(
            (product, id) =>
                <div key={id} >
                    <hr />
                    <div className="card">
                        <div className="row" >
                            <div className="column left" >
                                {
                                    <img src={`data:image/png;base64,${product.product_images}`} />
                                }
                            </div>
                            <div className="column right" >
                                <h3>&nbsp; {product.product_name}</h3>
                                {product.short_desc}<br />
                                <h5> {product.price}</h5>
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <button className="btn btn-outline-primary" >Buy Now</button>
                                            </td>
                                            <td>
                                                <button className="btn btn-outline-primary " name={id} onClick={this.displayProduct}>
                                                    Add to cart
                                                </button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <br />
                </div>

        ) : <div>

            </div>

        return (
            <React.Fragment>

                <div>
                    {this.state.showProduct ?
                        <React.Fragment>
                            <Product id={this.state.productId} productList={this.state.productsList} />
                            <button className="btn btn-outline-primary" onClick={this.goBack}>Back</button>
                        </React.Fragment>
                        : products}
                </div>

            </React.Fragment>
        )
    }
}