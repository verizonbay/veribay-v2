import React from 'react'

import { Link, NavLink } from 'react-router-dom'

const Navbar = ({ userData }) => {
    return (
        <React.Fragment>
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <Link className="navbar-brand" to="/">VeriBay</Link>

                <button
                    className="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav ml-auto">

                        {!userData &&
                            <React.Fragment>
                                <NavLink className="nav-link" to="/login">Login</NavLink>

                                <NavLink className="nav-link" to="/register">Register</NavLink>
                            </React.Fragment>
                        }
                        {userData &&
                            <React.Fragment>
                                <NavLink className="nav-link" to="/profile">{userData.split('-')[0].split('@')[0]}</NavLink>
            
                                <NavLink className="nav-link" to="/logout">Logout</NavLink>
                            </React.Fragment>
                        }

                    </ul>
                </div>
            </nav >
        </React.Fragment>
    )
}

export default Navbar;