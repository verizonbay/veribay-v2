import React from 'react'
import profile from '../assets/profilePic2.jpg';
import { Link } from 'react-router-dom'
import AwesomeSlider from 'react-awesome-slider';
import '../styles.css';
import Bidding from '../components/Bidding';
//import 'react-awesome-slider/dist/styles.css';
export default class Product extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            productList: this.props.productList,
            productId: this.props.id,
            product: this.props.productList[this.props.id]
        }
    }


    goToPayment = () => {
        this.setState({
            showProductDesc: true
        })
    }

    render() {

        let productDesc = <div className="mycard">

            <div className="card-body">
            <div className="mycolumn myleft">
            <img src={profile} className="rounded" width="100" /><br/> &nbsp;{this.state.product.username}
            </div>
                <div className="mycolumn myright">
 {/* <AwesomeSlider style={{width:"20%"}} >
    <div data-src="/path/to/one.jpg" style ={{height:"70px", width:"50px"}}/>
    <div data-src="/path/to/two.jpg" />
    <div data-src="/path/to/three.jpg" />
  </AwesomeSlider>  */}
                
                <h3>{this.state.product.short_desc}</h3><br/>
                <h5>Item Condition: <strong>New</strong></h5>
                {this.state.product.long_desc}<br/><br/>
                <Bidding minbid={this.state.product.minimum_bid} price={this.state.product.price} username={this.state.product.username}/>

                Price: &nbsp;&nbsp; Rs.{this.state.product.price}
                
                <table>
                    <tbody>
                        <tr>
                            <td>
                                <Link to="/payment">  <button onClick={this.goToPayment} className="btn btn-outline-primary">Buy Now</button></Link>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>
        </div>

        return (
            <div>
 
                {productDesc}
            </div>
        )
    }
}