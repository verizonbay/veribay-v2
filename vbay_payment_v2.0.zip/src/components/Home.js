import React from 'react'
import ProductsView from './ProductsView';
import Wishlist from './Wishlist';

export default class Home extends React.Component {

    constructor() {
        super();
        this.state = {
            showWishListComponent: false
        }
    }


    render() {
        return (
            <div className="container-fluid">
                <div className="row">
                    <div>
                        <ProductsView />
                    </div>

                </div>
            </div>
        )
    }
}