import React from 'react' 

export default class NotFound extends React.Component {
    render(){
        return(
            <React.Fragment>
                <h1>Not Fount</h1>
            </React.Fragment>
        )
    }
}