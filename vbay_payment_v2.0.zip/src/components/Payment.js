import React from 'react'
import axios from 'axios';
import Joi from 'joi-browser';


export default class Payment extends React.Component {

    // constructor(){
    //     super()
    //     this.state = {
    //         showDelivery:false
    //     }
    // }

    // goToDelivery = () => {
    //     this.setState({
    //         showDelivery: true
    //     })
    // }

    // render() {

    //     let payment = <div>Payment
    //                         <button className="btn btn-outline-primary" onClick={this.goToDelivery}>PAY</button>
    //                    </div>

    //     return (
    //         <div>
    //              {(this.state.showDelivery)?<Delivery />:payment}
    //         </div>
    //     )
    // }


    schema = {
      //  name_on_card: Joi.string().required(),
        first: Joi.string().regex(/^[0-9]{4}$/).required(),
        second: Joi.string().regex(/^[0-9]{4}$/).required(),
        third: Joi.string().regex(/^[0-9]{4}$/).required(),
        fourth: Joi.string().regex(/^[0-9]{4}$/).required(),
        expiry_month: Joi.number().min(1).max(12).required(),
        expiry_year:Joi.number().min(20).max(99).required(),
        cvv:Joi.string().regex(/^[0-9]{3}$/).required()


    }

    validate = () => {

        const options = { abortEarly: false }
        const { error } = Joi.validate({  first: this.state.first,second:this.state.second,third:this.state.third,fourth:this.state.fourth,expiry_month:this.state.expiry_month,expiry_year:this.state.expiry_year,cvv:this.state.cvv }, this.schema, options)

        if (!error) return null;

        const errors = {}
        for (let item of error.details)
            errors[item.path[0]] = item.message
        alert("Enter Valid Card Details")
        console.log(errors)
        return errors


    }

    constructor() {
        super()
        this.state = {
            cards: [],
            addClicked: true,
            expiry_month: 0,
            expiry_year: 0,
            card_no: "",
            cvv: 0,
            name_on_card: "",
            errors: {},
            first: "",
            second: "",
            third: "",
            fourth: ""


        }
    }

    componentDidMount() {
        // axios.get("http://localhost:8081/api/details")
        //     .then(response => {
        //         this.setState({ cards: response.data })
        //     })
        //     .catch(error => console.log(error))
    }
    newCard = () => {
        console.log(this.state)
        
        const errors = this.validate();
        console.log(errors);
        this.setState({ errors });
        if (errors) return;

        
        let cardData=new FormData()
        cardData.append("first",this.state.first)
        cardData.append("second",this.state.second)
        cardData.append("third",this.state.third)
        cardData.append("fourth",this.state.fourth)
        cardData.append("expiry_month",this.state.expiry_month)
        cardData.append("expiry_year",this.state.expiry_year)
        cardData.append("cvv",this.state.cvv)

        axios.post("http://192.168.20.121:8098/cardDB", cardData)
        .then(response => console.log(response))
        .catch(error => console.log(error))

        this.setState(
            { addClicked: !this.state.addClicked }

        )
    }
    addCard = () => {
        //axios.post("http://localhost:8081/api/details", {});
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    validateCard=()=>{
        axios.get("http://localhost:8081/api/details")
            .then(response => {
                this.setState({ cards: response.data })
            })
            .catch(error => console.log(error))


    }


    render() {

        let cardLayout = <table>
            <tbody>

                <tr>
                    <td>
                        <input type="text" style={{ width: '100px' }} className="form-control"
                             placeholder="CARD NO" name="first" onChange={this.handleChange} />&nbsp;&nbsp;
                    </td>
                    <td>
                        <input type="text" style={{ width: '100px' }} className="form-control"
                             placeholder="CARD NO" name="second" onChange={this.handleChange} />&nbsp;&nbsp;
                    </td>
                    <td>
                        <input type="text" style={{ width: '100px' }} className="form-control"
                            placeholder="CARD NO" name="third" onChange={this.handleChange} />&nbsp;&nbsp;
                     </td>
                    <td>
                        <input type="text" style={{ width: '100px' }} className="form-control" 
                            placeholder="CARD NO" name="fourth" onChange={this.handleChange} />&nbsp;&nbsp;
    
                   </td>
                </tr>
                <tr>
                    <td> <input type="text" style={{ width: '100px' }} className="form-control"
                             placeholder="MM" name="expiry_month" onChange={this.handleChange} />&nbsp;&nbsp;</td>
                    <td> <input type="text" style={{ width: '100px' }} className="form-control"
                             placeholder="YY" name="expiry_year" onChange={this.handleChange} />&nbsp;&nbsp;</td>
                    <td></td>
                    <td> <input type="text" style={{ width: '100px' }} className="form-control"
                             placeholder="CVV" name="cvv" onChange={this.handleChange} />&nbsp;&nbsp;</td>
                </tr>
            </tbody>
        </table>


        return (
            <div className="container">
                <div className="panel-heading">
                    <div className="row" >
                        <h3 className="text-center">Payment Details</h3>< br />
                    </div>
                    <div>
                        <img className="img-responsive cc-img" style={{ width: '405px' }}
                            alt="../assets/profilePic2.jpg"
                            src="http://www.prepbootstrap.com/Content/images/shared/misc/creditcardicons.png" />
                    </div>
                    {/* <div class="row">
                            <div class="col-xs-12">
                                <button class="btn btn-warning btn-lg btn-block" onClick={this.newCard} >Add Card</button>
                            </div>
                        </div> */}
                </div>
                {this.state.addClicked ?
                    
                        <div>
                            <div className="panel-body" >
                                <form>
                                    <div className="row">
                                        <div >
                                            {cardLayout}                                            
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div className="panel-footer">
                                <div className="row">
                                    <div className="col-xs-9">
                                        <button className="btn btn-warning btn-lg">Buy Now</button>
                                    </div> &emsp; &emsp; &emsp; &emsp;
                                    <div className="col-xs-3" style={{ paddingLeft: "100px" }}>
                                        <button className="btn btn-success btn-lg mr-auto pull-right" onClick={this.newCard}>Add Card</button>
                                    </div>
                                </div>
                            </div>                        
                    </div> :

                    <div>

                        <div>
                            <div className="panel-body" >
                                <form>
                                    <div className="row">
                                        <div >
                                            <div>
                                                <br></br>
                                                <input type="text" placeholder="Card Holder's Name" className="form-control"/>
                                                <br></br>
                                                {cardLayout}
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div className="panel-footer">
                                <div className="row">
                                    <div className="col-xs-9">
                                        <button className="btn btn-warning btn-lg" onClick={this.validateCard}>Buy Now</button>
                                    </div>
                                    <div className="col-xs-3" style={{ paddingLeft: "100px" }}>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                }

            </div>

        )
    }

}