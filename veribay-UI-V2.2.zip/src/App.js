import React from 'react'

import { Route, Redirect, Switch } from 'react-router-dom'

import NotFound from './components/NotFound';
import Login from './components/Login';
import Logout from './components/Logout';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Register from './components/Register';
import Profile from './components/Profile';
import Payment from './components/Payment';

export default class App extends React.Component {

    state = {}

    componentDidMount() {
        this.setState({
            userData: localStorage.getItem("userData")
        })
    }

    render() {
        return (
            <React.Fragment>
                <Navbar userData={this.state.userData} />
                <main className="container">
                    <Switch>
                        <Route path="/login" component={Login} />
                        <Route path="/register" component={Register} />
                        <Route path="/home" component={Home} />
                        <Route path="/profile" component={Profile} />
                        <Route path="/logout" component={Logout} />
                        <Route path="/notfound" component={NotFound} />
                        <Route path="/payment" component={Payment} />
                        <Redirect from="/" exact to="/home" />
                        <Redirect to="/notfound" />
                    </Switch>
                </main>
            </React.Fragment>
        )
    }
}
