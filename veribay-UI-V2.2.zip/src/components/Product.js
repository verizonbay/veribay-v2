import React from 'react'

import { Link } from 'react-router-dom'
export default class Product extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            productList: this.props.productList,
            productId: this.props.id,
            product: this.props.productList[this.props.id]
        }
    }


    goToPayment = () => {
        this.setState({
            showProductDesc: true
        })
    }

    render() {

        let productDesc = <div className="card">
            <div className="card-title">
                {this.state.product.username}
            </div>
            <div className="car-body">
                {this.state.product.short_desc}
                <table>
                    <tbody>
                        <tr>
                            <td>
                                <Link to="/payment">  <button onClick={this.goToPayment} className="btn btn-outline-primary">Buy Now</button></Link>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        return (
            <div>
                {productDesc}
            </div>
        )
    }
}